<?php

namespace App\Filament\Resources\PrdBrandResource\Pages;

use App\Filament\Resources\PrdBrandResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePrdBrand extends CreateRecord
{
    protected static string $resource = PrdBrandResource::class;
}
