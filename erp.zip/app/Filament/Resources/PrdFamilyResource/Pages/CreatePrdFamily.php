<?php

namespace App\Filament\Resources\PrdFamilyResource\Pages;

use App\Filament\Resources\PrdFamilyResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePrdFamily extends CreateRecord
{
    protected static string $resource = PrdFamilyResource::class;
}
