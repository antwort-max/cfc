<?php

namespace App\Filament\Resources\QuaCommitteeActionResource\Pages;

use App\Filament\Resources\QuaCommitteeActionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateQuaCommitteeAction extends CreateRecord
{
    protected static string $resource = QuaCommitteeActionResource::class;
}
