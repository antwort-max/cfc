<?php

namespace App\Filament\Resources\QuaCommitteeMeetingResource\Pages;

use App\Filament\Resources\QuaCommitteeMeetingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateQuaCommitteeMeeting extends CreateRecord
{
    protected static string $resource = QuaCommitteeMeetingResource::class;
}
