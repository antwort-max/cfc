<?php

namespace App\Filament\Resources\QuaCorrectiveActionResource\Pages;

use App\Filament\Resources\QuaCorrectiveActionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateQuaCorrectiveAction extends CreateRecord
{
    protected static string $resource = QuaCorrectiveActionResource::class;
}
