<?php

namespace App\Filament\Resources\QuaNonconformityResource\Pages;

use App\Filament\Resources\QuaNonconformityResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateQuaNonconformity extends CreateRecord
{
    protected static string $resource = QuaNonconformityResource::class;
}
