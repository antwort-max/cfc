<?php

namespace App\Filament\Resources\WebMenuResource\Pages;

use App\Filament\Resources\WebMenuResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWebMenu extends CreateRecord
{
    protected static string $resource = WebMenuResource::class;
}
