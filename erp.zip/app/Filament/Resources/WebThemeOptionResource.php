<?php

namespace App\Filament\Resources;

use App\Filament\Resources\WebThemeOptionResource\Pages;
use App\Models\WebThemeOption;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class WebThemeOptionResource extends Resource
{
    protected static ?string $model = WebThemeOption::class;

    protected static ?string $navigationIcon = 'heroicon-o-cog-6-tooth';
    protected static ?string $navigationGroup = 'Sitio Web';
    protected static ?string $modelLabel = 'Opción de Tema';
    protected static ?string $pluralModelLabel = 'Opciones de Tema';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Select::make('theme_mode')
                    ->label('Modo de Tema')
                    ->options([
                        'light' => 'Claro',
                        'dark' => 'Oscuro',
                        'auto' => 'Automático',
                    ])
                    ->required(),

                Forms\Components\TextInput::make('font_family')
                    ->label('Fuente')
                    ->default('Roboto'),

                Forms\Components\Select::make('button_style')
                    ->label('Estilo de Botón')
                    ->options([
                        'rounded' => 'Redondeado',
                        'flat' => 'Plano',
                        'outline' => 'Contorno',
                    ])
                    ->required(),

                Forms\Components\Select::make('layout_type')
                    ->label('Diseño')
                    ->options([
                        'boxed' => 'Caja',
                        'fullwidth' => 'Pantalla Completa',
                    ])
                    ->required(),

                Forms\Components\Toggle::make('status')
                    ->label('Activo')
                    ->default(true),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('theme_mode')->label('Tema'),
                Tables\Columns\TextColumn::make('font_family')->label('Fuente'),
                Tables\Columns\TextColumn::make('button_style')->label('Botón'),
                Tables\Columns\TextColumn::make('layout_type')->label('Diseño'),
                Tables\Columns\IconColumn::make('status')->label('Activo')->boolean(),
            ])
            ->defaultSort('id', 'desc')
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListWebThemeOptions::route('/'),
            'create' => Pages\CreateWebThemeOption::route('/create'),
            'edit' => Pages\EditWebThemeOption::route('/{record}/edit'),
        ];
    }
}
