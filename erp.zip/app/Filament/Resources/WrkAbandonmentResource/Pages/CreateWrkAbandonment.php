<?php

namespace App\Filament\Resources\WrkAbandonmentResource\Pages;

use App\Filament\Resources\WrkAbandonmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkAbandonment extends CreateRecord
{
    protected static string $resource = WrkAbandonmentResource::class;
}
