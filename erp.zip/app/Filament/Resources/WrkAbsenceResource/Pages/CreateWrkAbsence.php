<?php

namespace App\Filament\Resources\WrkAbsenceResource\Pages;

use App\Filament\Resources\WrkAbsenceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkAbsence extends CreateRecord
{
    protected static string $resource = WrkAbsenceResource::class;
}
