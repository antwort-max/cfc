<?php

namespace App\Filament\Resources\WrkAreaResource\Pages;

use App\Filament\Resources\WrkAreaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkArea extends CreateRecord
{
    protected static string $resource = WrkAreaResource::class;
}
