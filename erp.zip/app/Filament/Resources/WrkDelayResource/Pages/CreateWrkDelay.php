<?php

namespace App\Filament\Resources\WrkDelayResource\Pages;

use App\Filament\Resources\WrkDelayResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkDelay extends CreateRecord
{
    protected static string $resource = WrkDelayResource::class;
}
