<?php

namespace App\Filament\Resources\WrkDepartmentResource\Pages;

use App\Filament\Resources\WrkDepartmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkDepartment extends CreateRecord
{
    protected static string $resource = WrkDepartmentResource::class;
}
