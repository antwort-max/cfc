<?php

namespace App\Filament\Resources\WrkDiaryResource\Pages;

use App\Filament\Resources\WrkDiaryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkDiary extends CreateRecord
{
    protected static string $resource = WrkDiaryResource::class;
}
