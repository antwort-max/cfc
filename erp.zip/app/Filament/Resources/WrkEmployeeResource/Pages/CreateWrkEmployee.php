<?php

namespace App\Filament\Resources\WrkEmployeeResource\Pages;

use App\Filament\Resources\WrkEmployeeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkEmployee extends CreateRecord
{
    protected static string $resource = WrkEmployeeResource::class;
}
