<?php

namespace App\Filament\Resources\WrkLicenseResource\Pages;

use App\Filament\Resources\WrkLicenseResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkLicense extends CreateRecord
{
    protected static string $resource = WrkLicenseResource::class;
}
