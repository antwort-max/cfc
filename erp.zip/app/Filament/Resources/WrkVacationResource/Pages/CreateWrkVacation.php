<?php

namespace App\Filament\Resources\WrkVacationResource\Pages;

use App\Filament\Resources\WrkVacationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWrkVacation extends CreateRecord
{
    protected static string $resource = WrkVacationResource::class;
}
