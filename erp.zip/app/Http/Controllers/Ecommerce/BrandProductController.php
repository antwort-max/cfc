<?php

namespace App\Http\Controllers\Ecommerce;

use App\Http\Controllers\Controller;
use App\Models\PrdProduct;
use App\Models\PrdBrand;
use Illuminate\Http\Request;

class BrandProductController extends Controller
{

    public function show(PrdBrand $brand)
    {
        $topBanner = (object) [
            'status' => true,
            'text'  => 'Nuestra Casa Matriz se encuentra en Matucana #959, Santiago, Chile',
            'bg_color' => 'black',    
        ];

        $saleBanner = (object) [
            'address' => 'Matucana #959, Santiago, Chile',
            'phone'   => '+56 9 1234 5678',
        ];
        
        // Obtiene productos de la marca
        $products = PrdProduct::with(['family', 'subfamily', 'brand'])
            ->where('brand_id', $brand->id)
            ->get();

        // Familias únicas en estos productos
        $families = $products
            ->pluck('family')
            ->filter()
            ->unique('id')
            ->values();

        // Marcas únicas (aunque es solo una en este caso)
        $brands = $products
            ->pluck('brand')
            ->filter()
            ->unique('id')
            ->values();
            
        return view('ecommerce.products.list', compact('products', 'families', 'brands', 'topBanner', 'saleBanner'))->with('currentBrand', $brand);;
    }


}