<?php 


namespace App\Http\Controllers\Ecommerce;

use App\Http\Controllers\Controller;
use App\Services\CartService;
use App\Models\EcoCartItem;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function store(Request $request, CartService $cart): RedirectResponse
    {
        $request->validate([
            'product_id' => 'required|exists:prd_products,id',
            'quantity'   => 'required|integer|min:1',
        ]);

        $cart->addProduct(
            productId: $request->integer('product_id'),
            quantity : $request->integer('quantity', 1)
        );

        return back()->with('success', 'Producto añadido al carrito');
    }

    public function show(CartService $cart)
    {
        return view('ecommerce.cartPage.index', ['cart' => $cart->current()->load('items.product'), ]);
    }

    public function update(EcoCartItem $item, Request $request)
    {
        $request->validate(['quantity' => 'required|integer|min:1']);
        $item->update(['quantity' => $request->quantity]);
        
        return back()->with('success', 'Cantidad actualizada');
    }

    public function destroy(EcoCartItem $item)
    {
        $item->delete();
        
        return back()->with('success', 'Producto eliminado');
    }
}
