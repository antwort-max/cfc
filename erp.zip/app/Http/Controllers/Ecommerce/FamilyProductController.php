<?php

namespace App\Http\Controllers\Ecommerce;

use App\Http\Controllers\Controller;
use App\Models\PrdProduct;
use App\Models\PrdFamily;
use Illuminate\Http\Request;

class FamilyProductController extends Controller
{
    /**
     * Muestra productos filtrados por familia.
     *
     * @param  PrdFamily  $family
     * @return \Illuminate\View\View
     */
    public function show(PrdFamily $family)
    {
        // Banners
        $topBanner = (object) [
            'status'   => true,
            'text'     => 'Nuestra Casa Matriz se encuentra en Matucana #959, Santiago, Chile',
            'bg_color' => 'bg-black',
        ];

        $saleBanner = (object) [
            'address' => 'Matucana #959, Santiago, Chile',
            'phone'   => '+56 9 1234 5678',
        ];

        // Obtiene productos de la familia
        $products = PrdProduct::with(['family', 'subfamily', 'brand'])
            ->where('family_id', $family->id)
            ->get();

        // Familias únicas (solo la misma, pero para consistencia)
        $families = $products
            ->pluck('family')
            ->filter()
            ->unique('id')
            ->values();

        // Marcas únicas en estos productos
        $brands = $products
            ->pluck('brand')
            ->filter()
            ->unique('id')
            ->values();

        // Renderiza la lista reutilizando la vista de productos
        return view('ecommerce.products.list', compact(
            'products',
            'families',
            'brands',
            'topBanner',
            'saleBanner'
        ))->with('currentFamily', $family);
    }
}
