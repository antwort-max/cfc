<?php

namespace App\Http\Controllers\Ecommerce;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NavigationController extends Controller
{
    public function landingPage() {
        
        $topBanner = (object) [
            'status' => true,
            'text'  => 'Nuestra Casa Matriz se encuentra en Matucana #959, Santiago, Chile',
            'bg_color' => 'black',    
        ];

        $saleBanner = (object) [
            'address' => 'Matucana #959, Santiago, Chile',
            'phone'   => '+56 9 1234 5678',
        ];

        return view('ecommerce.landingPage.index', compact('topBanner', 'saleBanner'));
    }
}