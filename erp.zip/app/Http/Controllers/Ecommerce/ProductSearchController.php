<?php

namespace App\Http\Controllers\Ecommerce;

use App\Http\Controllers\Controller;
use App\Models\PrdProduct;
use App\View\Components\TopBanner;
use Illuminate\Http\Request;

class ProductSearchController extends Controller
{
    public function index(Request $request)
    {
        $topBanner = (object) [
            'status' => true,
            'text'  => 'Nuestra Casa Matriz se encuentra en Matucana #959, Santiago, Chile',
            'bg_color' => 'black',    
        ];

        $saleBanner = (object) [
            'address' => 'Matucana #959, Santiago, Chile',
            'phone'   => '+56 9 1234 5678',
        ];

        $q = $request->input('q');

        $products = PrdProduct::with(['family', 'subfamily'])
            ->where(function($query) use ($q) {
                $query->where('sku', 'like', "%{$q}%")
                      ->orWhere('name', 'like', "%{$q}%")
                      ->orWhere('description', 'like', "%{$q}%")
                      ->orWhereHas('family', function($qf) use ($q) {
                          $qf->where('name', 'like', "%{$q}%");
                      })
                      ->orWhereHas('subfamily', function($qs) use ($q) {
                          $qs->where('name', 'like', "%{$q}%");
                      });
            })
            ->get();
        
        $families = $products
            ->pluck('family')        
            ->filter()                 
            ->unique('id')             
            ->values();                
        
        $brands = $products
            ->pluck('brand')
            ->filter()
            ->unique('id')
            ->values();

        return view('ecommerce.products.list', compact('products', 'families', 'brands', 'topBanner', 'saleBanner'));
    }
}
