<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CusCustomer extends Model
{

    protected $table = 'cus_customers';

    protected $fillable = [
        'user_id',
        'rut',
        'first_name',
        'last_name',
        'email',
        'phone',
        'mobile',
        'company',
        'address_street',
        'address_city',
        'address_region',
        'address_zip',
        'notes',
        'status',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

}
