<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EcoCart extends Model
{

    protected $table = 'eco_carts';

    protected $fillable = [
        'id',
        'customer_id',
        'user_id',
        'status',
        'ip_address',
        'explanation',
        'amount',
        'taxes',
        'send_method',

    ];

    public const STATUS_DRAFT     = 0;
    public const STATUS_PENDING   = 1;
    public const STATUS_PAID      = 2;
    public const STATUS_ABANDONED = 3;

    protected $attributes = [
        'status' => self::STATUS_DRAFT,
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function customer()
    {
        return $this->belongsTo(CusCustomer::class, 'customer_id');
    }

    public function items()
    {
        return $this->hasMany(EcoCartItem::class, 'cart_id');   // FK = cart_id
    }

}