<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WrkDelay extends Model
{
    use HasFactory;

    protected $table = 'wrk_delays';

    protected $fillable = [
        'employee_id',
        'delay_date',
        'delay_time',
        'reason',
    ];

    protected $casts = [
        'delay_date' => 'date',
    ];

    public function employee()
    {
        return $this->belongsTo(WrkEmployee::class, 'employee_id');
    }
}
