@extends('ecommerce.layouts.app')

@section('title', 'Carrito de compras')

@section('content')
    <div class="max-w-5xl mx-auto my-12">
        <h1 class="text-3xl font-bold mb-6">Carrito</h1>

        @if ($cart->items->isEmpty())
            <p class="text-gray-600">Tu carrito está vacío.</p>
        @else
            <table class="w-full table-auto text-sm">
                <thead class="border-b">
                    <tr>
                        <th class="py-2 text-left">Producto</th>
                        <th class="py-2">Cantidad</th>
                        <th class="py-2 text-right">Subtotal</th>
                        <th class="py-2"></th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($cart->items as $item)
                        <tr class="border-b">
                            {{-- Nombre --}}
                            <td class="py-3">{{ $item->name }}</td>

                            {{-- Formulario PATCH cantidad --}}
                            <td class="py-3">
                                <form action="{{ route('cart.update', $item) }}" method="POST"
                                    class="inline-flex items-center gap-1">
                                    @csrf
                                    @method('PATCH')
                                    <input type="number" name="quantity" min="1"
                                        value="{{ $item->quantity }}"
                                        class="w-16 border rounded text-center">
                                    <button type="submit"
                                            class="px-2 py-1 bg-primary text-white rounded">
                                        ↻
                                    </button>
                                </form>
                            </td>

                            {{-- Subtotal --}}
                            <td class="py-3 text-right">
                                ${{ number_format($item->package_price * $item->quantity, 0, ',', '.') }}
                            </td>

                            {{-- Botón DELETE --}}
                            <td class="py-3 text-right">
                                <form action="{{ route('cart.destroy', $item) }}" method="POST">
                                    @csrf @method('DELETE')
                                    <button type="submit"
                                            class="p-2 text-red-600 hover:text-red-800">
                                        🗑️
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
@endsection
