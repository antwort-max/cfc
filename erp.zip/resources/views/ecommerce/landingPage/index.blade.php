{{-- resources/views/ecommerce/landingPage/index.blade.php --}}
@extends('ecommerce.layouts.app')   

@section('content')
    @if(isset($topBanner) && $topBanner->status) <x-top-banner :banner="$topBanner" /> @endif

    @include('partials.sale-banner', ['saleBanner' => $saleBanner])



    <div class="flex items-center justify-center py-32">

        <h1 class="text-4xl font-bold text-primary">
            LandingPage
        </h1>
    </div>
@endsection
