@extends('ecommerce.layouts.app')

@section('content')

    @if(isset($topBanner) && $topBanner->status) <x-top-banner :banner="$topBanner" /> @endif

    @include('sale-banner', ['saleBanner' => $saleBanner])
    
  <div class="container mx-auto py-8">
    <h4 class="text-2xl font-semibold mb-6 text-center">Productos Encontrados : {{ $products->count() }} </h4>
    @if($products->isEmpty())
      <p class="text-gray-600">No se encontraron productos para tu búsqueda.</p>
    @else

        {{-- Marcas como tags --}}
        @if(isset($brands) && $brands->isNotEmpty())
            <h5 class="text-lg font-semibold mb-2 text-center"><small>Marcas:</small></h5>
            <div class="flex flex-wrap gap-2 mb-4 justify-center">
                @foreach($brands as $brand)
                    <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                        <small>
                          <a href="{{ route('products.byBrand', $brand) }}">
                            {{ $brand->name }}
                          </a>
                        </small>
                    </span>
                @endforeach
            </div>
        @endif

        {{-- Familias como tags --}}
        @if(isset($families) && $families->isNotEmpty())
            <h5 class="text-lg font-semibold mb-2 text-center"><small>Familias:</small></h5>
            <div class="flex flex-wrap gap-2 mb-6 justify-center">
                @foreach($families as $family)
                    <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                        <small>
                          <a href="{{ route('products.byFamily', $family) }}">
                            {{ $family->name }}
                          </a>
                        </small>
                    </span>
                @endforeach
            </div>
        @endif

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach($products as $product)
          {{-- resources/views/ecommerce/components/domain/product-card.blade.php --}}
          <div class="flex flex-col bg-white rounded-lg shadow-sm overflow-hidden">
              {{-- Top: datos del producto --}}
              <div class="p-4 grow">
                  {{-- SKU --}}
                  <span class="block text-[0.7rem] uppercase tracking-wide text-gray-400 mb-1">
                      {{ $product->sku }}
                  </span>

                  {{-- Nombre --}}
                  <h3 class="text-base font-semibold text-gray-800 mb-1 leading-snug">
                      {{ $product->name }}
                  </h3>

                  {{-- Familia | Marca --}}
                  <span class="block text-xs text-gray-500 mb-3">
                      {{ $product->family->name ?? '-' }} |
                      {{ $product->brand->name  ?? '-' }}
                  </span>

                  {{-- Precios --}}
                  <dl class="text-sm text-gray-700 space-y-1">
                      <div class="flex justify-between">
                          <dt>Ref. ({{ $product->unit }})</dt>
                          <dd>${{ number_format($product->unit_price, 0, ',', '.') }}</dd>
                      </div>
                      <div class="flex justify-between">
                          <dt>Venta ({{ $product->package_unit }})</dt>
                          <dd>${{ number_format($product->package_price, 0, ',', '.') }}</dd>
                      </div>
                  </dl>
              </div>
          </div>
        @endforeach
      </div>
    @endif
  </div>
@endsection
