<div class="w-full bg-white border-b mt-12">
  <div class="container mx-auto flex items-center justify-between px-4 py-2">
    <!-- Izquierda: Dirección y Teléfono -->
    <div class="flex items-center space-x-4">
      <span class="text-sm text-gray-700">  
        <x-link-button
            href="https://www.google.com/maps/dir/?api=1&origin"
            icon="ti ti-map-pin"
            color="gray"
          >
          {{ $saleBanner->address }}
        </x-link-button>
      </span>
      <span class="text-sm text-gray-700">
         <x-link-button
            href="https://www.google.com/maps/dir/?api=1&origin"
            icon="ti ti-phone"
            color="gray"
          >
          {{ $saleBanner->phone }}
        </x-link-button>
      </span>
    </div>

    <!-- Centro: Buscador de productos -->
    <div class="flex-1 px-4">
      <form action="{{ route('products.search') }}" method="GET" class="relative">
        <input
          type="text"
          name="q"
          placeholder="Buscar productos..."
          class="w-full border border-gray-300 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <button
          type="submit"
          class="absolute right-3 top-1/2 transform -translate-y-1/2 focus:outline-none">
          <!-- Icono de búsqueda -->
          <i class="ti ti-search"></i>
        </button>
      </form>
    </div>

    <!-- Derecha: Carro de compra y Login -->
    <div class="flex items-center space-x-4">
      <span class="text-sm text-gray-700">
        <x-link-button
            href="{{ route('cart.show') }}"
            icon="ti ti-shopping-cart"
            color="gray"
          >
          Carro
          </x-link-button>
      </span>
      <span class="text-sm text-gray-700">
         <x-link-button
            href="https://www.google.com/maps/dir/?api=1&origin"
            icon="ti ti-user"
            color="gray"
          >
          Login 
        </x-link-button>
      </span>
    </div>
  </div>
</div>
