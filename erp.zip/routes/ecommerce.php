<?php 

use Illuminate\Support\Facades\Routes;

Route::get('/',  [App\Http\Controllers\Ecommerce\NavigationController::class, 'landingPage'])->name('landingPage');
Route::get('/search-products', [\App\Http\Controllers\Ecommerce\ProductSearchController::class, 'index'])->name('products.search');
Route::get('/products/brand/{brand}', [App\Http\Controllers\Ecommerce\BrandProductController::class, 'show'])->name('products.byBrand');
Route::get('/products/family/{family}', [App\Http\Controllers\Ecommerce\FamilyProductController::class, 'show'])->name('products.byFamily');

Route::post('/cart-store',  [App\Http\Controllers\Ecommerce\CartController::class, 'store'])->name('cart.store');  
Route::get('/cart-show',   [App\Http\Controllers\Ecommerce\CartController::class, 'show'])->name('cart.show');    
Route::patch('/cart-update/{item}',  [App\Http\Controllers\Ecommerce\CartController::class, 'update'])->name('cart.update');
Route::delete('/cart-destroy/{item}', [App\Http\Controllers\Ecommerce\CartController::class, 'destroy'])->name('cart.destroy');
