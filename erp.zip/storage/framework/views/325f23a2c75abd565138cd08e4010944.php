   

<?php $__env->startSection('content'); ?>
    <?php if(isset($topBanner) && $topBanner->status): ?> <?php if (isset($component)) { $__componentOriginal3dafb3aa1b5d40b6fbe8429d03ffda90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3dafb3aa1b5d40b6fbe8429d03ffda90 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.top-banner','data' => ['banner' => $topBanner]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('top-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['banner' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($topBanner)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3dafb3aa1b5d40b6fbe8429d03ffda90)): ?>
<?php $attributes = $__attributesOriginal3dafb3aa1b5d40b6fbe8429d03ffda90; ?>
<?php unset($__attributesOriginal3dafb3aa1b5d40b6fbe8429d03ffda90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3dafb3aa1b5d40b6fbe8429d03ffda90)): ?>
<?php $component = $__componentOriginal3dafb3aa1b5d40b6fbe8429d03ffda90; ?>
<?php unset($__componentOriginal3dafb3aa1b5d40b6fbe8429d03ffda90); ?>
<?php endif; ?> <?php endif; ?>

    <?php echo $__env->make('partials.sale-banner', ['saleBanner' => $saleBanner], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



    <div class="flex items-center justify-center py-32">

        <h1 class="text-4xl font-bold text-primary">
            LandingPage
        </h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ecommerce.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/erp/resources/views/ecommerce/landingPage/index.blade.php ENDPATH**/ ?>