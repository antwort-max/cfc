<!DOCTYPE html>
<html lang="es" class="scroll-smooth antialiased">
<head>
    <!-- Evita parpadeos de AlpineJS -->
    <style>
      [x-cloak] { display: none !important; }
    </style>

    <!-- Meta básicos -->
    <meta charset="<?php echo e(config('meta.charset')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="<?php echo e(config('meta.viewport')); ?>">
    <meta name="description" content="<?php echo e(config('meta.description')); ?>">
    <meta name="author" content="<?php echo e(config('meta.author')); ?>">
    <meta name="robots" content="<?php echo e(config('meta.robots')); ?>">
    <link rel="canonical" href="<?php echo e(config('meta.canonical')); ?>">

    <!-- Keywords opcional -->
    <meta name="keywords" content="<?php echo e(config('meta.keywords')); ?>">

    <!-- Favicon y Apple Touch Icon -->
    <link rel="icon" href="<?php echo e(config('meta.favicon.ico')); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(config('meta.favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(config('meta.favicon.png_32')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(config('meta.favicon.png_16')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(config('meta.apple_touch_icon')); ?>">
    <link rel="manifest" href="<?php echo e(config('meta.manifest')); ?>">

    <!-- Open Graph -->
    <meta property="og:locale"      content="<?php echo e(config('meta.og.locale')); ?>">
    <meta property="og:site_name"   content="<?php echo e(config('meta.og.site_name')); ?>">
    <meta property="og:title"       content="<?php echo e(config('meta.og.title')); ?>">
    <meta property="og:description" content="<?php echo e(config('meta.og.description')); ?>">
    <meta property="og:image"       content="<?php echo e(config('meta.og.image')); ?>">
    <meta property="og:url"         content="<?php echo e(config('meta.og.url')); ?>">
    <meta property="og:type"        content="<?php echo e(config('meta.og.type')); ?>">

    <!-- Twitter Cards -->
    <meta name="twitter:card"        content="<?php echo e(config('meta.twitter.card')); ?>">
    <meta name="twitter:site"        content="<?php echo e(config('meta.twitter.site')); ?>">
    <meta name="twitter:creator"     content="<?php echo e(config('meta.twitter.creator')); ?>">
    <meta name="twitter:title"       content="<?php echo e(config('meta.twitter.title')); ?>">
    <meta name="twitter:description" content="<?php echo e(config('meta.twitter.description')); ?>">
    <meta name="twitter:image"       content="<?php echo e(config('meta.twitter.image')); ?>">

    <!-- Otros meta de seguridad y PWA -->
    <meta name="theme-color"         content="<?php echo e(config('meta.theme_color')); ?>">
    <meta name="referrer"            content="<?php echo e(config('meta.referrer')); ?>">
    <meta name="format-detection"    content="<?php echo e(config('meta.format_detection')); ?>">
    <meta http-equiv="Content-Security-Policy"
          content="<?php echo e(config('meta.csp')); ?>">

    <!-- JSON-LD Schema.org -->
    <script type="application/ld+json">
        <?php echo json_encode(config('meta.json_ld'), JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT); ?>

    </script>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@tabler/icons@latest/iconfont/tabler-icons.min.css"
    />

    <!-- Estilos y scripts -->
    <script src="https://cdn.tailwindcss.com?plugins=forms,typography,aspect-ratio,line-clamp"></script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="min-h-screen flex flex-col bg-gray-50 text-gray-900 font-sans">
    <main class="flex-grow">
     
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/html/erp/resources/views/ecommerce/layouts/app.blade.php ENDPATH**/ ?>