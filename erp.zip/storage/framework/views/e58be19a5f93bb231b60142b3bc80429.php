<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href' => '#', 'icon' => null, 'color' => 'gray']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href' => '#', 'icon' => null, 'color' => 'gray']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $classes = "inline-flex items-center px-3 py-1 rounded bg-{$color} text-{$color}-700 hover:bg-{$color}-200";
?>

<a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php if($icon): ?>
        <i class="<?php echo e($icon); ?> mr-1"></i>
    <?php endif; ?>
    <span class="hidden sm:inline">
        <?php echo e($slot); ?>

    </span>
</a>

<?php /**PATH /var/www/html/erp/resources/views/components/link-button.blade.php ENDPATH**/ ?>